package com.baloteli.baloteli;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BaloteliGangApplicationTests {

	@Test
	void contextLoads() {
	}

}
