package com.baloteli.baloteli;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BaloteliGangApplication {

	public static void main(String[] args) {
		SpringApplication.run(BaloteliGangApplication.class, args);
	}

}
